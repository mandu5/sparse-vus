Anonymous manuscript source. Compile from this directory with: tectonic main.tex
The official default TMLR review header is a template convention, not a submission receipt.
Published prior software is cited in the third person; its bibliographic author is preserved.
The paper discloses LLM use in a first-page footnote and its reproducibility paragraph.
