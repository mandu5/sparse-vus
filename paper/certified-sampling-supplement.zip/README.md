# Anonymous computational supplement: certified VUS threshold sampling

This archive contains the new threshold-sampling study's complete numerical,
integer-certificate, saturation and runtime ledgers, frozen implementations and
tests. It excludes raw datasets, upstream caches, named manuscripts, author
information, private declarations, Git history and execution logs. Earlier input
identity manifests are included only where the new acquisition protocol hashes
them. Third-party attribution and licenses are retained.

## Verify the transported evidence (Python standard library only)

```sh
python experiments/verify_anonymous_transport.py
python experiments/audit_certified_sampling_bundle_anonymous.py --output /tmp/anonymous-study-audit.json
```

Choose a fresh output filename. The second command verifies complete ledger
coverage, all eighteen sensitivity cells, exact integer decisions, saturation
witnesses, source commitments, overlap sensitivity and certificate costs. It
does not rerun metrics or acquire original input arrays.

## Anonymization and provenance

`ANONYMIZATION_MANIFEST.json` records each original and transported checksum,
metadata transformation and any renamed hash-addressed report. Machine hostnames
and other identifying metadata strings are omitted. Numeric JSON values, integer
endpoint strings and all scientific source implementations are preserved.
Dependent metadata hash references are rebound transparently. These derived
metadata bytes are not claimed to be historically identical frozen originals.

The original auditor is preserved byte for byte. Its explicitly named anonymous
copy changes only complete SHA256 string literals; the transport verifier checks
the corresponding Python AST equality. The manifest records both versions.
Existing frozen experiment scripts are historical implementations: do not append
new observations or another host's timings to supplied records.

## Install and test

```sh
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install '.[accelerate,research]'
python experiments/fetch_reference.py
python experiments/fast_vus_adapter.py --fetch
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest -q
```

Without fetched external reference sources, the corresponding tests explicitly
skip; obtaining the references enables those independent controls. The included
tests concern this study and exact/certified evaluators, not older manuscript
artifact pipelines. Runtime tables describe the original single-host runs.

## Reacquire the unchanged published inputs

```sh
python experiments/reproduce_msad_corpus.py --manifest-sha256 5617e4fdc0bb082ac910144212546e05cc009622e45b07b672e562a999e6bc59 --cache .cache/fresh-reproduction
```

The cache must be new. Omit `--limit` to reacquire all 128 series; a supplied
`--limit` is an explicitly partial smoke test. Source member and numerical-array
hashes are checked. Upstream availability and original dataset terms apply; no
raw data are redistributed. See `artifacts/msad-corpus-20261023/ATTRIBUTION.md`.

For independent evaluations use freshly acquired NPZ arrays and these APIs:

```python
from fractions import Fraction
import numpy as np
from sparse_vus.radix import sparse_pr_radix_jit
from sparse_vus.sampling import sampled_pr_radix_jit
from sparse_vus.sampling_bounds import certified_sampled_pr
with np.load("path/to/reacquired.npz", allow_pickle=False) as data:
    labels, scores = data["labels"], data["CNN"]
    exact = sparse_pr_radix_jit(labels, scores, 30)
    sampled = sampled_pr_radix_jit(labels, scores, 30, thresholds=250)
    certificate = certified_sampled_pr(labels, scores, 30, thresholds=len(labels))
    interval = (Fraction(certificate.lower_numerator, certificate.scale),
                Fraction(certificate.upper_numerator, certificate.scale))
```

The certificate encloses the ideal real-arithmetic target. Strict ordering uses
`certificate.certifies_greater_than(other)`, not rounded displayed decimals.
Constructive witnesses and independent integer audits are in
`experiments/exploration/`. AI systems assisted derivation, implementation,
analysis and drafting; these checks do not represent external peer review.
