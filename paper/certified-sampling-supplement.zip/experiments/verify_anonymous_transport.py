"""Verify every transported file and the SHA-only auditor derivation (stdlib)."""
import ast
import hashlib
import json
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
m = json.loads((root/'ANONYMIZATION_MANIFEST.json').read_text())
for entry in m['files']:
    p = (root/entry['path']).resolve()
    assert p.is_relative_to(root) and p.is_file(), entry['path']
    assert hashlib.sha256(p.read_bytes()).hexdigest() == entry['anonymous_sha256'], entry['path']
mapping = {e['source_sha256']: e['anonymous_sha256'] for e in m['files']
           if e.get('source_sha256') and e.get('transformation') != 'sha256_string_literals_only'}
old = ast.parse((root/'experiments/audit_certified_sampling_bundle.py').read_text())
new = ast.parse((root/'experiments/audit_certified_sampling_bundle_anonymous.py').read_text())
class Substitute(ast.NodeTransformer):
    def visit_Constant(self, node):
        if isinstance(node.value,str) and re.fullmatch('[0-9a-f]{64}',node.value):
            node.value = mapping.get(node.value,node.value)
        return node
assert ast.dump(Substitute().visit(old)) == ast.dump(new), 'Auditor logic changed'
print('PASS: transported checksums and SHA-only derived auditor')
